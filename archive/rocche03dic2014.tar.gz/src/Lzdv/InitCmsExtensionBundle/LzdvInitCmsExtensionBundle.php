<?php

namespace Lzdv\InitCmsExtensionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LzdvInitCmsExtensionBundle extends Bundle
{
}
